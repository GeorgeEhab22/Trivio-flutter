import 'package:auth/core/errors/failure.dart';
import 'package:auth/core/validator.dart';
import 'package:auth/domain/entities/post.dart';
import 'package:auth/domain/repositories/post_repo.dart';
import 'package:dartz/dartz.dart';

class CreatePostUseCase {
  final PostRepository repository;

  // الحد الأقصى لعدد الأحرف في الـ post
  static const int maxContentLength = 500;

  CreatePostUseCase(this.repository);

  Future<Either<Failure, Post>> call({
    required String userId,
    required String content,
    String? imageUrl,
    String? videoUrl,
    List<String>? tags,
  }) async {
    // التحقق من وجود userId
    if (userId.trim().isEmpty) {
      return const Left(ValidationFailure('User ID is required'));
    }

    // التحقق من صحة userId
    if (!Validator.isValidId(userId)) {
      return const Left(ValidationFailure('Invalid User ID'));
    }

    final trimmedContent = content.trim();

    // التأكد من وجود نص أو صورة أو فيديو
    if (trimmedContent.isEmpty &&
        (imageUrl == null || imageUrl.isEmpty) &&
        (videoUrl == null || videoUrl.isEmpty)) {
      return const Left(
        ValidationFailure('Post must have text or an image or video'),
      );
    }

    // التحقق من طول المحتوى
    if (trimmedContent.length > maxContentLength) {
      return Left(
        ValidationFailure('Post content cannot exceed $maxContentLength characters'),
      );
    }

    // التحقق من صلاحية URLs
    if (imageUrl != null && imageUrl.isNotEmpty && !Validator.isValidUrl(imageUrl)) {
      return const Left(ValidationFailure('Invalid image URL'));
    }

    if (videoUrl != null && videoUrl.isNotEmpty && !Validator.isValidUrl(videoUrl)) {
      return const Left(ValidationFailure('Invalid video URL'));
    }

    // إرسال البيانات للـ repository
    return await repository.createPost(
      userId: userId,
      content: trimmedContent,
      imageUrl: imageUrl,
      videoUrl: videoUrl,
      tags: tags,
    );
  }
}
