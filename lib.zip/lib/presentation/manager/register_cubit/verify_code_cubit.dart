import 'dart:async';

import 'package:auth/core/errors/failure.dart';
import 'package:auth/domain/usecases/register/resend_verification_code.dart';
import 'package:auth/domain/usecases/register/verify_code.dart' show VerifyCode;
import 'package:auth/presentation/manager/register_cubit/verify_code_state.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

class VerifyCodeCubit extends Cubit<VerifyCodeState> {
  final VerifyCode verifyCode;
  final ResendVerificationCode resendVerificationCode;

  final String username;
  final String email;
  Timer? _resendTimer;
  int _resendCountdown = 0;

  VerifyCodeCubit({
    required this.username,
    required this.verifyCode,
    required this.resendVerificationCode,
    required this.email,
  }) : super(const VerifyCodeInitial());

  int get resendCountdown => _resendCountdown;
  bool get canResend => _resendCountdown == 0;


  void startResendTimer({int seconds = 60}) {
    _resendTimer?.cancel();

    _resendCountdown = (seconds < 0) ? 0 : seconds;

    emit(VerifyCodeCountdown(_resendCountdown));


    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _resendCountdown--;

      if (_resendCountdown <= 0) {
        _resendCountdown = 0;
        timer.cancel();
        emit(const VerifyCodeCountdown(0));

        return;
      }

      emit(VerifyCodeCountdown(_resendCountdown));

    });
  }

  Future<void> verify(String code) async {
    if (code.length != 6) {
      emit(const VerifyCodeError('Please enter a valid 6-digit code.'));
      return;
    }

    emit(const VerifyCodeLoading());

    final result = await verifyCode(email: email, code: code);

    result.fold(
      (failure) => emit(VerifyCodeError(_mapFailureToMessage(failure))),
      (token) => emit(VerifyCodeSuccess(token: token)),
    );
  }

  Future<void> resend(String?newEmail) async {
    if (!canResend) return;
    emit(const VerifyCodeInitial());

    emit(const VerifyCodeLoading());

    final result = await resendVerificationCode(email,username);

    result.fold(
      (failure) => emit(VerifyCodeError(_mapFailureToMessage(failure))),
      (_) {
        emit(const VerifyCodeResent());
        startResendTimer();
      },
    );
  }

  String _mapFailureToMessage(Failure failure) {
    if (failure is ServerFailure) {
      return failure.message;
    } else if (failure is NetworkFailure) {
      return 'No internet connection';
    } else if (failure is ValidationFailure) {
      return failure.message;
    }
    return 'An unexpected error occurred';
  }

  @override
  Future<void> close() {
    _resendTimer?.cancel();
    return super.close();
  }
}
