import 'package:auth/presentation/home/share_post/share_buttom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/post_action_item.dart';


class ShareButton extends StatelessWidget {
  final int count;
  final VoidCallback onShare;

  const ShareButton({
    super.key,
    required this.count,
    required this.onShare,
  });


  void _openShareSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => ShareBottomSheet(
        onShare: onShare, // ✅ بنمررها للـ bottom sheet
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PostActionItem(
      icon: const FaIcon(FontAwesomeIcons.arrowUpFromBracket, size: 22),
      count: count,
      onTap: () => _openShareSheet(context),
    );
  }
}
