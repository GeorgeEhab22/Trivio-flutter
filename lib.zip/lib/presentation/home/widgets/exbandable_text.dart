import 'package:auth/constants/colors';
import 'package:flutter/material.dart';

class ExpandableText extends StatefulWidget {
  final String text;
  final int previewLines;
  final bool canCollapse; // لو true النص يرجع أصغر عند الضغط مرة تانية

  const ExpandableText({
    super.key,
    required this.text,
    required this.previewLines,
    this.canCollapse = true, // افتراضيًا ممكن يرجع أصغر
  });

  @override
  State<ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<ExpandableText> {
  bool _expanded = false;
  bool _isOverflowing = false;
  String? _trimmedText;

  static const textStyle16 = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w500,
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkOverflow());
  }

  void _checkOverflow() {
    final renderBox = context.findRenderObject() as RenderBox?;
    if (renderBox == null) return;

    final maxWidth = renderBox.size.width;

    final textPainter = TextPainter(
      text: TextSpan(text: widget.text, style: textStyle16),
      maxLines: widget.previewLines,
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: maxWidth);

    final isOverflow = textPainter.didExceedMaxLines;

    if (mounted) {
      setState(() {
        _isOverflowing = isOverflow;
        _trimmedText = isOverflow
            ? _trimText(widget.text, widget.previewLines, maxWidth)
            : widget.text;
      });
    }
  }

  void _toggleExpand() {
    if (_expanded && !widget.canCollapse) return; // لو مش مسموح بالطي مره اخرى
    setState(() => _expanded = !_expanded);
  }

  @override
  Widget build(BuildContext context) {
    final displayText = _expanded ? widget.text : (_trimmedText ?? widget.text);

    return GestureDetector(
      onTap: _toggleExpand,
      child: RichText(
        text: TextSpan(
          style: textStyle16.copyWith(color: AppColors.iconsColor),
          children: [
            TextSpan(text: displayText),
            if (_isOverflowing && !_expanded)
              WidgetSpan(
                alignment: PlaceholderAlignment.baseline,
                baseline: TextBaseline.alphabetic,
                child: Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Text(
                    '... more',
                    style: textStyle16.copyWith(
                      color: const Color(0xFF838383),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _trimText(String text, int maxLines, double maxWidth) {
    const seeMoreText = " ... more";

    int start = 0;
    int end = text.length;
    int mid;

    while (start < end) {
      mid = (start + end) ~/ 2;

      final painter = TextPainter(
        text: TextSpan(
          text: text.substring(0, mid) + seeMoreText,
          style: textStyle16,
        ),
        maxLines: maxLines,
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: maxWidth);

      if (painter.didExceedMaxLines) {
        end = mid;
      } else {
        start = mid + 1;
      }
    }

    final safeEnd = (end - 4).clamp(0, text.length);
    return text.substring(0, safeEnd);
  }
}
