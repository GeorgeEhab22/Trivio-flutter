import 'package:flutter/material.dart';
import 'package:auth/presentation/home/comments/widgets/comment_item.dart';

class CommentRepliesList extends StatelessWidget {
  final List<Map<String, dynamic>> replies;
  final void Function(String id, String newText) onEdit;
  final void Function(String id) onDelete;
  final void Function(String id, String username) onReply;

  const CommentRepliesList({
    super.key,
    required this.replies,
    required this.onEdit,
    required this.onDelete,
    required this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: replies.map((reply) {
        return CommentItem(
          comment: reply,
          onEdit: onEdit,
          onDelete: onDelete,
          onReply: onReply,
          isReply: true,
          replyingTo: reply["replyingTo"] ?? '',
        );
      }).toList(),
    );
  }
}
