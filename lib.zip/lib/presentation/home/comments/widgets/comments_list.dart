import 'package:flutter/material.dart';
import 'package:auth/presentation/home/comments/widgets/comment_item.dart';

class CommentsList extends StatelessWidget {
  final List<Map<String, dynamic>> comments;
  final GlobalKey<AnimatedListState> listKey;
  final void Function(String id, String newText) onEdit;
  final void Function(String id) onDelete;
  final void Function(String id, String username) onReply;
  final ScrollController scrollController;

  const CommentsList({
    super.key,
    required this.comments,
    required this.listKey,
    required this.onEdit,
    required this.onDelete,
    required this.onReply, required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
   
   return AnimatedList(
  key: listKey,
  controller: scrollController,   // ← أهي الإضافة
  reverse: true,
  padding: const EdgeInsets.symmetric(horizontal: 8),
  initialItemCount: comments.length,
  itemBuilder: (context, index, animation) {
    final comment = comments[index];
    return SizeTransition(
      sizeFactor: animation,
      axisAlignment: -1,
      child: FadeTransition(
        opacity: animation,
        child: CommentItem(
          comment: comment,
          onEdit: onEdit,
          onDelete: onDelete,
          onReply: onReply,
        ),
      ),
    );
  },
);

  }
}
