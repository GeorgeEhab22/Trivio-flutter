import 'package:flutter/material.dart';
import 'package:auth/presentation/home/comments/widgets/comment_header.dart';
import 'package:auth/presentation/home/comments/widgets/comment_body.dart';
import 'package:auth/presentation/home/comments/widgets/comment_replies_list.dart';

class CommentItem extends StatefulWidget {
  final Map<String, dynamic> comment;
  final void Function(String id, String newText) onEdit;
  final void Function(String id) onDelete;
  final void Function(String id, String username) onReply;

  final String? replyingTo;
  final bool isReply;

  const CommentItem({
    super.key,
    required this.comment,
    required this.onEdit,
    required this.onDelete,
    required this.onReply,
    this.replyingTo,
    this.isReply = false,
  });

  @override
  State<CommentItem> createState() => _CommentItemState();
}

class _CommentItemState extends State<CommentItem> {
  bool _showReplies = false;

  void _showEditDialog(String id, String oldText) {
    final controller = TextEditingController(text: oldText);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Edit Comment"),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: "Edit your comment...",
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              widget.onEdit(id, controller.text);
              Navigator.pop(context);
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final comment = widget.comment;
    final replies = List<Map<String, dynamic>>.from(comment["replies"] ?? []);

    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CommentHeader(
          user: comment["user"],
          time: comment["time"],
          commentText: comment["text"],
          onEdit: () => _showEditDialog(comment["id"], comment["text"]),
          onDelete: () => widget.onDelete(comment["id"]),
          onReply: () => widget.onReply(comment["id"], comment["user"]),
        ),

        if (widget.replyingTo != null && widget.replyingTo!.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 54, bottom: 4),
            child: Text(
              "Replying to ${widget.replyingTo}",
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),

        CommentBody(
          text: comment["text"],
          onReply: () => widget.onReply(comment["id"], comment["user"]),
          showReplies: _showReplies,
          repliesCount: replies.length,
          onToggleReplies: () => setState(() => _showReplies = !_showReplies),
          onReactionChanged: (int value) {},
        ),

        if (replies.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(
              left: widget.isReply ? 50 : 60,
              top: 4,
              bottom: 4,
            ),
            child: GestureDetector(
              onTap: () => setState(() => _showReplies = !_showReplies),
              child: Row(
                children: [
                  Icon(
                    _showReplies
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    size: 18,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _showReplies
                        ? "Hide replies"
                        : "View ${replies.length} replies",
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),

        if (_showReplies)
          CommentRepliesList(
            replies: replies,
            onEdit: (id, text) => _showEditDialog(id, text),
            onDelete: widget.onDelete,
            onReply: widget.onReply,
          ),
      ],
    );

    return widget.isReply
        ? Transform.scale(
            scale: 0.95,
            alignment: Alignment.topLeft,
            child: Container(
              margin: const EdgeInsets.only(left: 50, bottom: 6),
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FA),
                borderRadius: BorderRadius.circular(10),
              ),
              child: content,
            ),
          )
        : content;
  }
}
