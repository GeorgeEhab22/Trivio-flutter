import 'package:auth/presentation/authentication/widgets/show_custom_snackbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:auth/constants/colors';

class CommentActionsMenu extends StatelessWidget {
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onReply;
  final String commentText;
  final double iconSize;

  const CommentActionsMenu({
    super.key,
    required this.onEdit,
    required this.onDelete,
    required this.onReply,
    required this.commentText,
    this.iconSize = 18,
  });

  void _showActions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // ✅ Reply
              _buildActionTile(
                context,
                icon: Icons.reply_outlined,
                label: 'Reply',
                onTap: () {
                  Navigator.pop(context);
                  onReply();
                },
              ),

              _divider(),

              // ✅ Copy
              _buildActionTile(
                context,
                icon: Icons.copy_outlined,
                label: 'Copy',
                onTap: () async {
                  await Clipboard.setData(ClipboardData(text: commentText));
                  Navigator.pop(context);
                  showCustomSnackBar(context, 'Comment copied to clipboard', true);
                },
              ),

              _divider(),

              // ✅ Edit
              _buildActionTile(
                context,
                icon: Icons.edit_outlined,
                label: 'Edit',
                onTap: () {
                  Navigator.pop(context);
                  onEdit();
                },
              ),

              _divider(),

              // ✅ Delete
              _buildActionTile(
                context,
                icon: Icons.delete_outline,
                label: 'Delete',
                textColor: Colors.redAccent,
                iconColor: Colors.redAccent,
                onTap: () {
                  Navigator.pop(context);
                  onDelete();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _divider() => Divider(height: 1, color: Colors.grey[200]);

  Widget _buildActionTile(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? textColor,
    Color? iconColor,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: iconColor ?? AppColors.primary, size: 22),
            const SizedBox(width: 16),
            Text(
              label,
              style: TextStyle(
                fontSize: 16,
                color: textColor ?? Colors.black87,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.more_vert, size: iconSize, color: Colors.grey[700]),
      onPressed: () => _showActions(context),
    );
  }
}
