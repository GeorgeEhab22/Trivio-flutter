import 'package:flutter/material.dart';
import 'package:auth/core/styels.dart'; // صححت typo من "styels" لـ "styles"
import 'package:auth/common/functions/format_time.dart';
import 'package:auth/presentation/home/comments/widgets/comment_actions_menu.dart';
import 'package:auth/presentation/home/widgets/author_info.dart'; // استدعاء الـ widget الجديدة بشكل صحيح

class CommentHeader extends StatelessWidget {
  final String user;
  final String? userImage;
  final DateTime? time;
  final String commentText;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onReply;

  const CommentHeader({
    super.key,
    required this.user,
    this.userImage,
    required this.time,
    required this.commentText,
    required this.onEdit,
    required this.onDelete,
    required this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 👤 صورة المستخدم + الاسم + الوقت
          Expanded(
            child: AuthorInfo(
              author: user,
              timeAgo: formatTime(time),
              avatarRadius: 18,
              showTimeInline: true,
              authorTextStyle: Styles.textStyle15, authorImage: '', // أصغر شوية من البوست
            ),
          ),

          // ⋯ الأكشنز (edit / delete / reply)
          CommentActionsMenu(
            onEdit: onEdit,
            onDelete: onDelete,
            onReply: onReply,
            commentText: commentText,
          ),
        ],
      ),
    );
  }
}
