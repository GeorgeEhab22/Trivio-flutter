import 'package:flutter/material.dart';
import '../reactions/reaction_button.dart';
import '../comments/comment_button.dart';
import '../share_post/share_button.dart';
import 'save_button.dart';

class PostStates extends StatefulWidget {
  final int reactions;
  final int comments;
  final int shares;

  const PostStates({
    super.key,
    required this.reactions,
    required this.comments,
    required this.shares,
  });

  @override
  State<PostStates> createState() => _PostStatesState();
}

class _PostStatesState extends State<PostStates> {
  late int _reactionsCount;
  late int _commentCount;
  late int _shareCount;
  bool _isSaved = false;

  @override
  void initState() {
    super.initState();
    _reactionsCount = widget.reactions;
    _commentCount = widget.comments;
    _shareCount = widget.shares;
  }

  void _toggleSave() => setState(() => _isSaved = !_isSaved);
  void _incrementShares() => setState(() => _shareCount++);
  void _incrementComments() => setState(() => _commentCount++);
  void _decrementComments() => setState(() => _commentCount--);

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final double spacing = screenWidth < 350
        ? 12
        : screenWidth < 600
        ? 20
        : 28;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          ReactionButton(
            initialCount: _reactionsCount,
            onReactionChanged: (count) {
              setState(() => _reactionsCount = count);
              // ✅ TODO: call likePostUseCase(postId, userId)
            },
          ),
          SizedBox(width: spacing),
          CommentButton(
            count: _commentCount,
            onCommentAdded: _incrementComments,
            onCommentDeleted: _decrementComments,
                    // ✅ TODO: call commentOnPostUseCase(postId, userId, commentText)

          ),
          SizedBox(width: spacing),
          ShareButton(count: _shareCount, onShare: _incrementShares
                  // ✅ TODO: call sharePostUseCase(postId, userId)

          ),
          const Spacer(),
          SaveButton(isSaved: _isSaved, onTap: _toggleSave
                  // ✅ TODO: call toggleSavePostUseCase(postId, userId)

          ),
        ],
      ),
    );
  }
}
