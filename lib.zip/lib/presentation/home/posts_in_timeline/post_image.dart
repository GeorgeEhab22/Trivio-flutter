import 'package:flutter/material.dart';

class PostImage extends StatelessWidget {
  final String? imageUrl;
  final double? originalWidth;  // عرض الصورة الأصلي
  final double? originalHeight; // ارتفاع الصورة الأصلي

  const PostImage({super.key, this.imageUrl, this.originalWidth, this.originalHeight});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final imageWidth = screenWidth * 0.9; // 90% من عرض الشاشة
    double imageHeight;

    if (originalWidth != null && originalHeight != null) {
      // الحفاظ على نسبة العرض للارتفاع
      imageHeight = (originalHeight! / originalWidth!) * imageWidth;
    } else {
      // ارتفاع افتراضي لو الصورة غير متوفرة
      imageHeight = screenWidth * 0.5;
    }

    // تحديد حد أقصى للارتفاع
    const maxHeight = 400.0;
    if (imageHeight > maxHeight) imageHeight = maxHeight;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: imageWidth,
          height: imageHeight,
          color: Colors.grey[200],
          child: imageUrl != null
              ? Image.network(
                  imageUrl!,
                  width: imageWidth,
                  height: imageHeight,
                  fit: BoxFit.cover,
                )
              : Icon(
                  Icons.sports_soccer,
                  size: imageHeight * 0.25,
                  color: Colors.grey[500],
                ),
        ),
      ),
    );
  }
}
